﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jagjyot_Lab_6
{
    public abstract class Product
    {
        public Product(string name, string category, int quantity, double price)
        {
            Name = name;
            Category = category;
            Quantity = quantity;
            Price = price;
        }

        public string Name { get; set; }
        public string Category { get; set; }
        public int Quantity { get; set; }
        public double Price { get; set; }


        public abstract void Restock(int amount);
        public abstract void Sell(int amount);

    }

}
