﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jagjyot_Lab_6
{
    public class Beverage : Product
    {
        public double Volume { get; set; }

        public Beverage(string name, string category, int quantity, double price, double volume)
           : base(name, category, quantity, price)
        {
            this.Volume = volume;
        }

        public override void Restock(int qty)
        {
            if (qty > 0)
            {
                Quantity = Quantity + qty;
                Console.WriteLine($"{qty} - {Name} product restocked.");
                Console.WriteLine($"{Name} ({Category}) - {Quantity} units in stock, priced at ${Price:F2}");

            }
            else
            {
                throw new Exception($"Invalid quantity");
            }
        }

        public override void Sell(int amount)
        {
            if (Quantity >= amount)
            {
                Quantity = Quantity - amount;
                Console.WriteLine($"{amount} - {Name} product sold.");
                Console.WriteLine($"{Name} ({Category}) - {Quantity} units in stock, priced at ${Price:F2}");

            }
            else
            {
                throw new Exception($"Not enough stock available.");
            }
        }

    }
}
