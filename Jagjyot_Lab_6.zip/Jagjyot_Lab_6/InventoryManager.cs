﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;

namespace Jagjyot_Lab_6
{
    public class InventoryManager
    {
        private List<Product> inventory = new List<Product>();

        public void AddProduct(Product product)
        {
            try
            {
                Product found = FindProduct(product.Name);
                if (found == null)
                {
                    inventory.Add(product);
                    Console.WriteLine($"You have successfully added {product.Name} to the inventory");
                }
                else
                {
                    throw new Exception($"Product with name {product.Name} already exist in the inventory");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public void RemoveProduct(string name)
        {
            try
            {
                Product found = FindProduct(name);
                if (found != null)
                {
                    inventory.Remove(found);
                    Console.WriteLine("Product removed.");
                }
                else
                {
                    throw new Exception("Error: The product you are trying to remove does not exist in the inventory.");
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public void SearchProduct(string name)
        {
            try
            {
                Product product = FindProduct(name);
                if (product != null)
                {
                    Console.WriteLine($"{product.Name} ({product.Category}) - {product.Quantity} units in stock, priced at ${product.Price:F2}");
                }
                else
                {
                    throw new Exception("Error: The product you are trying to search does not exist in the inventory.");
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public void UpdateProductInfo(Product newProduct)
        {
            try
            {
                Product product = FindProduct(newProduct.Name);
                if (product != null)
                {
                    inventory.Remove(product);
                    inventory.Add(newProduct);
                    Console.WriteLine($"You have successfully updated {product.Name} to the inventory");

                }
                else
                {
                    throw new Exception("Error: The product you are trying to update does not exist in the inventory.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public void SellProduct(string name,int quantity)
        {
            try
            {
                Product product = FindProduct(name);
                if (product != null)
                {
                    product.Sell(quantity);
                }
                else
                {
                    throw new Exception("Error: The product you are trying to sell does not exist in the inventory.");
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public void RestockProduct(string name, int quantity)
        {
            try
            {
                Product product = FindProduct(name);
                if (product != null)
                {
                    product.Restock(quantity);
                }
                else
                {
                    throw new Exception("Error: The product you are trying to sell does not exist in the inventory.");
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private Product FindProduct(string name)
        {
            foreach (Product product in inventory)
            {
                if (product.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                {
                    return product;
                }

            }
            return null; 
        }
    }
}
