﻿using Jagjyot_Lab_6;
using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        InventoryManager manager = new InventoryManager();
        while (true)
        {
            Console.WriteLine("\n1. Add Product\n2. Remove Product\n3. Update Product\n4. Search Product\n5. Sell Product\n6. Restock Product\n7. Exit");
            Console.Write("Choose an option: ");
            string choice = Console.ReadLine();

            if (choice == "1")
            {
                Console.Write("Enter product name: ");
                string name = Console.ReadLine();
                Console.Write("Enter category: ");
                string category = Console.ReadLine();
                Console.Write("Enter quantity: ");
                int quantity = int.Parse(Console.ReadLine());
                Console.Write("Enter price: ");
                double price = double.Parse(Console.ReadLine());
                Console.Write("Enter volume: ");
                double volume = double.Parse(Console.ReadLine());

                Beverage newBeverage = new Beverage(name, category, quantity, price, volume);
                manager.AddProduct(newBeverage);
            }
            else if (choice == "2")
            {
                Console.Write("Enter product name to remove: ");
                string name = Console.ReadLine();
                manager.RemoveProduct(name);
            }
            else if (choice == "3")
            {
                Console.Write("Enter product name: ");
                string name = Console.ReadLine();
                Console.Write("Enter category: ");
                string category = Console.ReadLine();
                Console.Write("Enter quantity: ");
                int quantity = int.Parse(Console.ReadLine());
                Console.Write("Enter price: ");
                double price = double.Parse(Console.ReadLine());
                Console.Write("Enter volume: ");
                double volume = double.Parse(Console.ReadLine());

                Beverage newBeverage = new Beverage(name, category, quantity, price, volume);
                manager.UpdateProductInfo(newBeverage);
            }
            else if (choice == "4")
            {
                Console.Write("Enter product name to search: ");
                string name = Console.ReadLine();
                manager.SearchProduct(name);
            }
            else if (choice == "5")
            {
                Console.Write("Enter product name: ");
                string name = Console.ReadLine();
                Console.Write("Enter quantity: ");
                int quantity = int.Parse(Console.ReadLine());

                manager.SellProduct(name,quantity);
            }
            else if (choice == "6")
            {
                Console.Write("Enter product name: ");
                string name = Console.ReadLine();
                Console.Write("Enter quantity: ");
                int quantity = int.Parse(Console.ReadLine());

                manager.RestockProduct(name, quantity);
            }
            else if (choice == "7")
            {
                break;
            }
            else
            {
                Console.WriteLine("Invalid choice, try again.");
            }
        }
    }
}

